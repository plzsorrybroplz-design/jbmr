import { GraduationCap, Instagram, Facebook, Twitter, Linkedin } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-blue text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="bg-white p-2 rounded-lg">
                <GraduationCap className="w-6 h-6 text-brand-blue" />
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight">
                JBMR <span className="text-brand-yellow">Coaching</span>
              </span>
            </div>
            <p className="text-blue-100 max-w-sm mb-8 leading-relaxed">
              Excellence in education since our inception. We provide high-quality coaching for students from 6th to 12th grade, focusing on all-round development.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Instagram, Twitter, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="bg-white/10 p-2 rounded-lg hover:bg-white/20 transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-serif text-xl font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-blue-100">
              <li><a href="#" className="hover:text-brand-yellow transition-colors">Home</a></li>
              <li><a href="#courses" className="hover:text-brand-yellow transition-colors">Courses</a></li>
              <li><a href="#faculty" className="hover:text-brand-yellow transition-colors">Our Faculty</a></li>
              <li><a href="#contact" className="hover:text-brand-yellow transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-xl font-bold mb-6">Boards & Courses</h4>
            <ul className="space-y-4 text-blue-100">
              <li><span className="hover:text-brand-yellow transition-colors">UP Board (6-12th)</span></li>
              <li><span className="hover:text-brand-yellow transition-colors">CBSE Board (6-12th)</span></li>
              <li><span className="hover:text-brand-yellow transition-colors">ICSE Board (6-12th)</span></li>
              <li><span className="hover:text-brand-yellow transition-colors">English Speaking</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-blue-200 text-sm">© {currentYear} JBMR Coaching Classes. All rights reserved.</p>
          <div className="flex items-center space-x-2 text-blue-300 text-xs opacity-70">
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M23.53 10.512a.67.67 0 0 0-.106-.271 10.355 10.355 0 0 0-3.32-3.414 7.6 7.6 0 0 0-4.043-1.127 7.7 7.7 0 0 0-2.316.365 7.684 7.684 0 0 0-2.148 1.109 6.208 6.208 0 0 0-2.434-1.295 5.8 5.8 0 0 0-2.13-.178c-.808.083-1.579.378-2.228.852a4.42 4.42 0 0 0-1.442 1.936c-.23.633-.284 1.3-.158 1.942a4.34 4.34 0 0 0 .741 1.637c-.365.41-.652.884-.847 1.396A4.542 4.542 0 0 0 3 15.17a4.524 4.524 0 0 0 1.258 3.1 4.321 4.321 0 0 0 3.013 1.305 4.57 4.57 0 0 0 1.488-.13c.483-.153.931-.41 1.31-.75a8.213 8.213 0 0 0 3.321 2.378 9.013 9.013 0 0 0 3.38.647 8.165 8.165 0 0 0 4.148-1.077 8.358 8.358 0 0 0 3.1-2.973c.123-.2.12-.453-.008-.65-.127-.197-.348-.305-.578-.284a1.868 1.868 0 0 1-.806.012 2.112 2.112 0 0 1-1.396-1.115 11.231 11.231 0 0 0-1.35-2.072 1.614 1.614 0 0 1-.36-1.285c.08-.43.37-.788.775-.953a3.528 3.528 0 0 0 1.821-1.921 2.213 2.213 0 0 0-1.13-2.678 2.348 2.348 0 0 0-2.146.062s-.405.195-.515.244a1.21 1.21 0 0 1-1.272-.11 1.378 1.378 0 0 1-.491-1.259c.108-.574.453-1.077.954-1.389a3.784 3.784 0 0 1 1.898-.553 3.69 3.69 0 0 1 2.058.497 4.137 4.137 0 0 1 1.464 1.493c.142.247.33.456.554.613.224.156.483.25.753.275a.256.256 0 0 0 .235-.11.217.217 0 0 0-.012-.25z"/>
            </svg>
            <span>Network optimized and protected by Cloudflare</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
